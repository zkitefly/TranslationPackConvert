# 方块索引

本索引列出了TIS-3D的所有方块。 如果你是来寻找物品的，请前往[物品索引](../item/index.md)。

- [控制器](controller.md)
- [机箱](casing.md)
