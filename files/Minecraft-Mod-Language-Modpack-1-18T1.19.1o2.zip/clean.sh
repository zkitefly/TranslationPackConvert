export dLINK=$dLINK
export NAME=$NAME
export dNAMR=$dNAMR
export cV=$cV
export cNAMR=$cNAMR
export CM=$CM