# 转换率

**瓦**
- 1 J = 1 RF
- 1 J = 0.25 EU
- 1 J = 1 FE (forge energy)
- 1 Watt = 1 J/t

- (Watt)瓦特是流量
- (J)焦耳是能量

**蒸汽**
- 1 J = 蒸汽 0.5mB 
- 水|1mB = 蒸汽 10mB

- 太阳半径: 695.700 km