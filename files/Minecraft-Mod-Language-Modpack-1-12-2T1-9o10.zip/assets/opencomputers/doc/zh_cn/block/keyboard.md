# Keyboard

![QWERTY](oredict:oc:keyboard)

在[屏幕](screen1.md)上打字 , 或者嵌入 [机器人](robot.md) 和 [平板](../item/tablet.md).
