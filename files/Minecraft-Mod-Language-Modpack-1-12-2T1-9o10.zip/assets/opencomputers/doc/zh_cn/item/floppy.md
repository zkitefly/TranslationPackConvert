# 软盘

![Many inches.](oredict:oc:floppy)

最便宜的存储设备了，用于早期交换数据