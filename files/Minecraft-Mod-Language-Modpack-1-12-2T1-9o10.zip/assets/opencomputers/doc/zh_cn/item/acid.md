# 酸液

![Reflux?](oredict:oc:materialAcid)

可口的[citation needed] 遥指， 如果你想找点乐子的话就喝下去吧www。 当然这可能烧了你的食管. 也可以作为多种物资的原料

一个主要用处是从系统移除[纳米机器](nanomachines.md)

在困难模式下它用来把[电路板](circuitBoard.md) 刻蚀为 [印刷电路板](printedCircuitBoard.md).
