# 逻辑运算单元

![I can into logic!](oredict:oc:materialALU)

用来合成计算组件, 比如[CPU](cpu1.md)， [显卡](graphicsCard1.md).
