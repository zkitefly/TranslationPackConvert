# Motion Sensor

![Don't. Blink.](oredict:oc:motionSensor)

运动探测器允许 [电脑](../general/computer.md)探测生物. 如果生物移速快过阈值，将会向连接的电脑发出红石信号 [computers](../general/computer.md)
阈值可以在连接的电脑上用组件API调节
探测范围8格, 不能有障碍物,生物走出范围或者连线上有障碍都会使得生物无法被探测。
