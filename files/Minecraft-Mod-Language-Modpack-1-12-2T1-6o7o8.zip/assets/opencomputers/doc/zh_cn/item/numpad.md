# Numeric Keypad

![Check for fingerprints.](oredict:oc:materialNumPad)

数字键是 [键盘](../block/keyboard.md).的配件，允许输入数字. 