![融魂钢制探测器轨道](block:betterwithmods:detector_rail_steel)

融魂钢制探测器轨道会在乘有玩家的矿车经过时发射红石信号